package cs3500.freecell.hw04;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class HashMapExample {

  public static void main(String[] args) {

    Map<String, Integer> hm =
        new HashMap<String, Integer>();
    hm.put("a", 100);
    hm.put("b", 200);
    hm.put("c", 300);
    hm.put("d", 400);

    hm.remove("a");
    System.out.println(hm.containsKey("a"));
  }

}
